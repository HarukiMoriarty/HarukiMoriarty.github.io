#!/bin/bash

# setup.sh: A script to update system, and install rust and protobuf-compiler

# Get the username of the user who called sudo
ORIGINAL_USER=$(who am i | awk '{print $1}')

# Ensure the script is run with superuser privileges
if [[ $EUID -ne 0 ]]; then
    echo "This script must be run as root" 
    exit 1
fi

# Update the package lists for upgrades and new package installations
echo "Updating package lists..."
apt update -y

# Upgrade all upgradable packages
echo "Upgrading existing packages..."
apt upgrade -y

# Install the Protocol Buffers Compiler
echo "Installing Protocol Buffers Compiler..."
apt install -y protobuf-compiler

# Confirm the installations
echo -n "Protoc version: "
protoc --version

# Check if ORIGINAL_USER variable is empty or not set
if [ -z "$ORIGINAL_USER" ]; then
    echo "Cannot determine the original user who invoked the script. Exiting."
    exit 1
fi

# Install Rust programming language and its package manager Cargo as the original user
echo "Installing Rust and Cargo as user: $ORIGINAL_USER ..."
# Using sudo -u to run the rustup command as the original user
sudo -u $ORIGINAL_USER bash << RUSTSCRIPT
# We will use curl to download rustup and pipe it to sh for installation
# We will use the --quiet flag with rustup to disable interactive prompts
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y

# To use Rust and Cargo, we should update our shell PATH
# Add Rust's bin directory to the user PATH by adding the line to the user shell configuration file
echo "export PATH=\$PATH:\$HOME/.cargo/bin" >> "\$HOME/.bashrc"
# Load the new PATH to the current shell session
source "\$HOME/.bashrc"
RUSTSCRIPT

# Confirm the installations as the original user
sudo -u $ORIGINAL_USER bash -i -c 'rustc --version'

echo "Setup completed successfully!"
